import os

def find_dot_prefixed_files_and_dirs(root_dir):
    dot_prefixed_items = []
    items = os.listdir(root_dir)
    for item in items:
        if item.startswith('.'):
            dot_prefixed_items.append(os.path.join(root_dir, item))
    return dot_prefixed_items

root_dir = '.' 
dot_prefixed_items = find_dot_prefixed_files_and_dirs(root_dir)

i = 0
for item in dot_prefixed_items:
    os.system(f'cp -r {item} dotfiles')
    print(f'{i}: {item}')
    i += 1
